let hours = document.getElementById("hoursInput");
let minutes = document.getElementById("minutesInput");
let error = document.getElementById("errorMsg");
let converted = document.getElementById("timeInSeconds");
let convertButton = document.getElementById("convertBtn");
let seconds = 0;
convertButton.addEventListener("click", function() {
    if (hours.value === "") {
        error.textContent = "Please enter a valid number of hours";
        hours.value = "";
        minutes.value = "";
    } else if (minutes.value === "") {
        error.textContent = "Please enter a valid number of minutes";
        hours.value = "";
        minutes.value = "";
    } else {
        error.textContent = "";
        seconds = seconds + parseInt(hours.value) * 60 * 60;
        seconds = seconds + parseInt(minutes.value) * 60;
        converted.classList.add("convertedTime");
        converted.textContent = seconds + 's';
    }
});